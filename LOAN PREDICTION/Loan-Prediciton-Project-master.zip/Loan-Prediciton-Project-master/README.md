![Python](https://img.shields.io/badge/Python-3.x-red) ![ML](https://img.shields.io/badge/Machine-Learning-blue) ![Status](https://img.shields.io/badge/Status-Completed-success) ![DS](https://img.shields.io/badge/Data-Science-ff69b4)

# Loan-Prediciton

This Repository contains the Loan Prediction Project created by using 4 different Machine Learning Algorithms.

**Classification Algorithms used:**
1. Logistic Regression (LR)
2. Super Vector Machine (SVM)
3. Decision Tree 
4. K-Nearest Neighbor (KNN)
